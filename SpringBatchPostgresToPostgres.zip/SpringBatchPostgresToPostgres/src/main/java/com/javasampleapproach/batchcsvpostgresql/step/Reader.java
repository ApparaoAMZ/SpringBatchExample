package com.javasampleapproach.batchcsvpostgresql.step;

import java.time.LocalTime;

import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.core.io.ClassPathResource;

import com.javasampleapproach.batchcsvpostgresql.model.Application;
import com.javasampleapproach.batchcsvpostgresql.model.Customer;

public class Reader {
	public static FlatFileItemReader<Application> reader(String path) {
		FlatFileItemReader<Application> reader = new FlatFileItemReader<Application>();
		System.out.println("start of call:: "+LocalTime.now());
		reader.setResource(new ClassPathResource(path));
		reader.setLineMapper(new DefaultLineMapper<Application>() {
			{
				setLineTokenizer(new DelimitedLineTokenizer() {
					{
						setNames(new String[] { "id", "firstName", "lastName" });
					}
				});
				setFieldSetMapper(new BeanWrapperFieldSetMapper<Application>() {
					{
						setTargetType(Application.class);
					}
				});
			}
		});
		return reader;
	}
}
