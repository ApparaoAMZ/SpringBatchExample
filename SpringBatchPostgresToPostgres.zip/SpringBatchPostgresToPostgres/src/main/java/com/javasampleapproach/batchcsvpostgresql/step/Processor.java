package com.javasampleapproach.batchcsvpostgresql.step;

import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

import com.javasampleapproach.batchcsvpostgresql.model.Application;
import com.javasampleapproach.batchcsvpostgresql.model.Customer;

public class Processor implements ItemProcessor<Application, Application> {

	private static final Logger log = LoggerFactory.getLogger(Processor.class);

	@Override
	public Application process(Application application) throws Exception {
		String candidateId=null;
		String felony_conviction_question_1__c=null;
		String requisition_hiring_function__c=null;
		String national_id_country_ps__c=null;
		String candidate_withdraws_detail__c=null;
		int id;
		candidateId="TTCan1";
		felony_conviction_question_1__c="TTXFe1";
		requisition_hiring_function__c="TTI2";
		national_id_country_ps__c="TTNIDS2";
	    candidate_withdraws_detail__c="TTCWCWD2";
		
		
		final Application fixedApplication = new Application(application.getId(), candidateId, felony_conviction_question_1__c,requisition_hiring_function__c,national_id_country_ps__c,candidate_withdraws_detail__c);

		//log.info("Converting (" + application + ") into (" + fixedApplication + ")");

		return fixedApplication;
	}
}
