package com.javasampleapproach.batchcsvpostgresql.config;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.javasampleapproach.batchcsvpostgresql.model.Application;



public class ApplicationRowMapper implements RowMapper<Application> {

	@Override
	public Application mapRow(ResultSet rs, int rowNum) throws SQLException {
		Application app = new Application(rs.getInt("id"),rs.getString("candidate__c"),rs.getString("felony_conviction_question_1__c"),rs.getString("requisition_hiring_function__c"),rs.getString("national_id_country_ps__c"),rs.getString("candidate_withdraws_detail__c"));
		
		return app;
	}

}
