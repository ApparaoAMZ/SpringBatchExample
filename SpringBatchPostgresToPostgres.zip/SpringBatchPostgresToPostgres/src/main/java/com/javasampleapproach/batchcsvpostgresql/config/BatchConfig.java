package com.javasampleapproach.batchcsvpostgresql.config;

import java.time.LocalTime;

import javax.sql.DataSource;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.database.JdbcCursorItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.javasampleapproach.batchcsvpostgresql.dao.ApplicationDao;
import com.javasampleapproach.batchcsvpostgresql.model.Application;
import com.javasampleapproach.batchcsvpostgresql.model.Customer;
import com.javasampleapproach.batchcsvpostgresql.step.Listener;
import com.javasampleapproach.batchcsvpostgresql.step.Processor;
import com.javasampleapproach.batchcsvpostgresql.step.Reader;
import com.javasampleapproach.batchcsvpostgresql.step.Writer;

@Configuration
@EnableBatchProcessing
public class BatchConfig {

	@Autowired
	public JobBuilderFactory jobBuilderFactory;

	@Autowired
	public StepBuilderFactory stepBuilderFactory;

	@Autowired
	public ApplicationDao applicationDao;
	
	@Autowired
	private DataSource dataSource;
	
	@Bean
	public JdbcCursorItemReader<Application> reader(){
		System.out.println("start of call:: "+LocalTime.now());
		JdbcCursorItemReader<Application> cursorItemReader = new JdbcCursorItemReader<>();
		cursorItemReader.setDataSource(dataSource);
		cursorItemReader.setSql("select id,candidate__c, felony_conviction_question_1__c, requisition_hiring_function__c, national_id_country_ps__c, candidate_withdraws_detail__c from heroku_depersonalisation.application__c");
		cursorItemReader.setRowMapper(new ApplicationRowMapper());
		return cursorItemReader;
	}
	

	@Bean
	public Job job() {
		return jobBuilderFactory.get("job").incrementer(new RunIdIncrementer()).listener(new Listener(applicationDao))
				.flow(step1()).end().build();
		
	}

	@Bean
	public Step step1() {
		return stepBuilderFactory.get("step1").<Application, Application>chunk(10000)
				.reader(reader())
				.processor(new Processor()).writer(new Writer(applicationDao)).build();
	}
}
